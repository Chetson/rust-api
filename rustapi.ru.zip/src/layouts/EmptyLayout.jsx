import { Outlet } from 'react-router-dom'

export default function EmptyLayout ({ children }) {
    return (
        <div className="server-select">
            <Outlet />
            {children}
        </div>
    )
}
